  *****************************************************
  *  With credits to the authors:                     *
  *  shimodax & emaijala,                             *
  *  http://forum.thinkpads.com/viewtopic.php?t=17715 *
  *  Yariv Kaplan                                     *
  *  http://www.internals.com/                        *
  *  Alexandre Elias                                  *
  *  http://winhlp.com/WxACPIEC.htm                   *
  *****************************************************


1.  unzipp to any place you like... 

-------------------------------------------------------

2. >>>>>>>>>>>>>>> install as service:

    double klick "install.bat"

    no reboot necessary
--------------------------------------------------------

3.  The service is installed as running automatically, but
    if you want to start/stop the service, copy tpfcstart &
    tpfcstop to your desktop or any folder shown on taskbar.

--------------------------------------------------------

4. >>>>>>>>>>>>>>> changing settings:

    AFTER installation double klick "settings"

    change settings, save and exit

    double klick restart.bat

   /given settings are for T4x, X3x
   /usage and changing settings at your own risk!!

--------------------------------------------------------

5. >>>>>>>>>>>>>>> optional:


  a) to stop acpi-embedded-controler from spamming system.log
     switch to acpi-embedded-controler with NoLog-Option
     "acpiecnl.sys" instead of original "acpiec.sys"

       double click on:  instecnl.bat

       double click on:  acpiecLogOff.reg  

       confirm the registry change and reboot.

     Attention: now no error is reported from acpiec!


  b) to switch back to original embedded-controler "acpiec.sys"

       double click on:  acpiecLogOn.reg   

       confirm the registry change and reboot.

     c:\windows\system32\drivers\acpiecnl.sys  remains, 
     don't mind or delete manually if you like.
--------------------------------------------------------

6. >>>>>>>>>>>>>>> uninstall:


    double klick "uninstall.bat"

    no reboot necessary

--------------------------------------------------------

7.  delete unzipped files

========================================================

batch files:

*install.bat: 
  md c:\tpfancontrol
  copy *.* c:\tpfancontrol
  c:\tpfancontrol\fancontrol_service.exe -i
  net start TPFanControl

*settings:
  notepad.exe c:\tpfancontrol\fancontrol.ini
 
*restart.bat:
  net stop TPFanControl
  net start TPFanControl

*instecnl.bat:
  copy acpiecnl.sys c:\windows\system32\drivers
	 
*uninstall.bat:
  net stop TPFanControl
  c:\tpfancontrol\fancontrol_service.exe -u
  del c:\tpfancontrol\*.* /Q
  rd c:\tpfancontrol
