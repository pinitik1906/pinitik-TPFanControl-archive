 
  *****************************************************
  *  With credits to the authors:                     *
  *  DE: mit Dank an:                                 *
  *  shimodax & emaijala,                             *
  *  http://forum.thinkpads.com/viewtopic.php?t=17715 *
  *  Yariv Kaplan                                     *
  *  http://www.internals.com/                        *
  *  Alexandre Elias                                  *
  *  http://winhlp.com/WxACPIEC.htm                   *
  *  Sander "Iconman"                                 *
  *  http://a-st.de                                   *
  *****************************************************

0.  Any difficulties? Read the thread / bei Schwierigkeiten:
    http://forum.thinkpads.com/viewtopic.php?t=17715

1.  unzipp to any place you like...
    DE: irgendwohin entpacken... 

-------------------------------------------------------

2.  >>>>>>>>>>>>>>> install as service:

    WinXP: double klick "install.bat"
           no reboot necessary

           This program was writen for WinXP, but if you want to run it in
    Vista32: 
           open start menu 
           type cmd 
           right click on cmd.exe and select "run as administrator" 
           navigate to the directory you downloaded the tpfancontrol files to 
           type install
           TPFancontrol will run and work, but 
           there will not be any GUI or icon in Vista unless
           you start tpfcicon.exe afterwards

    
    WinXP: DE: >>>>>>>>  als Dienst installieren:
           DE: doppelklick auf install.bat
           DE: kein Neustart erforderlich

    Vista32: DE: nach c:/tpfancontrol entpacken
             DE: install.bat mit admin Rechten starten
             DE: tpfcicon.exe auf den Desktop kopieren und starten

---------------------------------------------------------------

3.  The service is installed as running automatically, but
    if you want to start/stop the service, copy tpfcstart &
    tpfcstop to your desktop or any folder shown on taskbar.

    DE: Der Dienst installiert so, dass er automatisch beim
    DE: Hochfahren des Notebooks startet. Wenn Du ihn per Hand 
    DE: starten oder stoppen m�chtest, einfach tpfcstart & tpfcstop
    DE: auf den Desktop kopieren oder in einen Ordner, der in der
    DE: Taskbar angezeigt wird. Dann jeweils Doppelklick drauf.

--------------------------------------------------------------

4. >>>>>>>>>>>>>>> changing settings:

    AFTER installation double klick "settings",
    change settings, save and exit,
    double klick restart.bat

    given settings are for T4x, X3x
    usage and changing settings at your own risk!!

    DE: >>>>>>>>>>>>>>Einstellungen �ndern:
    DE: nach der Installation doppelklick auf "settings"
    DE: Einstellungen ver�ndern, speichern und schliessen.
    DE: Doppelklick auf retsart.bat
    DE:
    DE: die vorgegeben Werte sind f�r T4x, X3x
    DE: Gebrauch des Programms auf eigene Gefahr !!

--------------------------------------------------------

5. >>>>>>>>>>>>>>> optional for WinXP 32bit:


  a) to stop acpi-embedded-controler from spamming system.log
     switch to acpi-embedded-controler with NoLog-Option
     "acpiecnl.sys" instead of original "acpiec.sys"

     double click on:  instecnl.bat
     double click on:  acpiecLogOff.reg  
     confirm the registry change and reboot.

     Attention: now no error is reported from acpiec!


  b) to switch back to original embedded-controler "acpiec.sys"

       double click on:  acpiecLogOn.reg   
       confirm the registry change and reboot.

     c:\windows\system32\drivers\acpiecnl.sys  remains, 
     don't mind or delete manually if you like.



     DE: >>>>>>>>>>>>>>> optional:
     DE:
     DE: a)Um den acpi-embedded-controler davon abzuhalten das system.log
     DE:   mit Meldungen zu �berfluten, wechsele zum acpi-embedded-controler
     DE:   mit NoLog-Option.
     DE: 
     DE:   "acpiecnl.sys" anstatt des originalen "acpiec.sys"
     DE:   benutzen und das geht so:
     DE: 
     DE:   doppelklick auf:  instecnl.bat
     DE:   doppelklick auf:  acpiecLogOff.reg  
     DE: 
     DE:   Wechsel best�tigen und Neustart des Notebook
     DE:
     DE: Achtung: Fehler werden jetzt nicht mehr vom acpiec
     DE:          in das system.log eingetragen
     DE:
     DE:  b) um wieder zum originalen embedded-controler "acpiec.sys"
     DE:     zur�ckzukehren:
     DE:     doppelklick auf:  acpiecLogOn.reg   
     DE:     Wechsel best�tigen und Neustart des Notebook.
     DE:
     DE:  Die Datei: c:\windows\system32\drivers\acpiecnl.sys 
     DE:  bleibt bestehen, macht aber nichts, 
     DE:  nach Belieben von Hand l�schen

--------------------------------------------------------

6. >>>>>>>>>>>>>>> uninstall:

    double klick "uninstall.bat" or "c:/tpfancontrol/uninstall.bat"
    no reboot necessary

    DE: >>>>>>>>>>>>> deinstallieren:
    DE: doppelklick auf "uninstall.bat" oder "c:/tpfancontrol/uninstall.bat"
    DE: Neustart nicht erforderlich
--------------------------------------------------------

7.  delete unzipped files
    program folder is now c:\tpfancontrol

    DE: die downgeloadeten zip-Dateien und die 
    DE: entpackten Dateien k�nnen gel�scht werden.
    DE: Das Programmverzeichnis ist jetzt c:\tpfancontrol

========================================================

    contents of batch files are:

    DE: der Inhalt der .bat-Dateien:

*install.bat: 
  md c:\tpfancontrol
  copy *.* c:\tpfancontrol
  c:\tpfancontrol\fancontrol_service.exe -i
  net start TPFanControl

*settings:
  notepad.exe c:\tpfancontrol\fancontrol.ini
 
*restart.bat:
  net stop TPFanControl
  net start TPFanControl

*instecnl.bat:
  copy acpiecnl.sys c:\windows\system32\drivers
	 
*uninstall.bat:
  net stop TPFanControl
  c:\tpfancontrol\fancontrol_service.exe -u
  del c:\tpfancontrol\*.* /Q
  rd c:\tpfancontrol

*tpfcstart
  link to "net start TPFanControl"

*tpfcstop
  link to "net stop TPFanControl"

