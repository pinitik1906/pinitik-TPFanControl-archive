********************************************************
!!!!!Usage of this software is at your own risk!!!!!!!!!
********************************************************
!!!Vista users!!!: Most of the things that can be simply 
"double-clicked" in XP require administration privileges
to work properly in Vista. This includes: 
fancontrol.exe 
install_service 
uninstall_service 
start_service 
stop_service 
All of these require a right click->"Run as administrator".
THnx for hint to Xtal@forum.thinkpads.com
*******************************************************
0.  run uninstall.bat of older TPFanControl, if exists
    delete old files & folder C:\tpfancontrol, if exists
********************************************************

1.  DOUBLE CLICK setup.exe,  that means:

    setup.exe expands all the files to C:\tpfancontrol
--------------------------------------------------------

2.  DOUBLE CLICK TVicPortInstall41.exe, that means:

    Install driver by 
    start->run->  C:\tpfancontrol\TVicPortInstall41.exe
    have ALL these little boxes (Delphi etc.) UNCHECKED 
    mind the license agreement, reboot not necessary
--------------------------------------------------------

3.  DOUBLE CLICK fancontrol.exe,  that means:

    start->run->  C:\tpfancontrol\fancontrol.exe
    mind start delay by SecWinUptime & SecStartDelay
    and value of StartMinimized, all in fancontrol.ini
--------------------------------------------------------

4.  DOUBLE CLICK settings,  that means:

    start->run->  C:\tpfancontrol\settings
    default settings are for T4x, X3x, R5x
    to change settings edit fancontrol.ini, save & exit:
********************************************************
5. install & start service:

stop fancontrol 1st (menue item "End Program", if exists)

DOUBLE CLICK  install_service,  that means:
start->run->  C:\tpfancontrol\fancontrol -i    
   installs service running automatically from boot time

DOUBLE CLICK  start_service,   that means:
start->run->  net start TPFanControl      starts service

having tpfc as service under vista to get digital icon:
DOUBLE CLICK  tpfcicon.exe     that means:
start->run->  C:\tpfancontrol\tpfcicon.exe
--------------------------------------------------------
6.  stop & uninstall service or program:

stop fancontrol 1st (menue item "End Program", if exists)

DOUBLE CLICK  stop_service,   that means:
start->run->  net stop TPFanControl        stops service

DOUBLE CLICK  uninstall_service,  that means:
start->run->  C:\tpfancontrol\fancontrol -u   

delete files & folder to end usage
********************************************************
Read: http://forum.thinkpads.com/viewtopic.php?t=17715
faq: http://www.staff.uni-marburg.de/~schmitzr/donate.html
credits to the authors: Sander"Iconman"http://a-st.de
and Shimodax & emaijala @ http://forum.thinkpads.com 
********************************************************
!!!!!Usage of this software is at your own risk!!!!!!!!!
********************************************************